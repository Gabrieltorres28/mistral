import { UserCheck, Clock, Target } from "lucide-react"

const highlights = [
  {
    icon: UserCheck,
    title: "Atención personalizada",
    description: "Cada proyecto recibe seguimiento directo para asegurar resultados.",
  },
  {
    icon: Clock,
    title: "Cumplimiento y respuesta",
    description: "Plazos claros y comunicación constante durante todo el trabajo.",
  },
  {
    icon: Target,
    title: "Soluciones a medida",
    description: "Nos adaptamos a las necesidades específicas de cada cliente.",
  },
]

export function About() {
  return (
    <section id="nosotros" className="bg-secondary py-16 lg:py-24">
      <div className="mx-auto max-w-6xl px-4 lg:px-6">
        <div className="grid items-center gap-12 lg:grid-cols-2 lg:gap-16">
          {/* Text content */}
          <div>
            <h2 className="text-2xl font-bold tracking-tight text-foreground sm:text-3xl">
              Quiénes somos
            </h2>
            <div className="mt-6 space-y-4 text-muted-foreground">
              <p className="text-pretty leading-relaxed">
                Somos una empresa de servicios metalúrgicos con experiencia en trabajos industriales, 
                de construcción y mantenimiento. Nuestro equipo está formado por técnicos y soldadores 
                con trayectoria comprobada en el sector.
              </p>
              <p className="text-pretty leading-relaxed">
                Trabajamos con empresas de distintos rubros, ofreciendo soluciones prácticas, 
                cumplimiento en los tiempos pactados y calidad en cada entrega.
              </p>
            </div>
          </div>

          {/* Highlights */}
          <div className="grid gap-4 sm:grid-cols-1">
            {highlights.map((item) => (
              <div
                key={item.title}
                className="flex items-start gap-4 border-l-2 border-primary bg-background p-4"
              >
                <div className="flex h-10 w-10 shrink-0 items-center justify-center bg-primary">
                  <item.icon className="h-5 w-5 text-primary-foreground" />
                </div>
                <div>
                  <h3 className="font-semibold text-foreground">{item.title}</h3>
                  <p className="mt-1 text-sm text-muted-foreground">{item.description}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  )
}
