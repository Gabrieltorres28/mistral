import Link from "next/link"

export function Footer() {
  return (
    <footer className="border-t border-border bg-background py-10">
      <div className="mx-auto max-w-6xl px-4 lg:px-6">
        <div className="flex flex-col items-center gap-6 text-center md:flex-row md:justify-between md:text-left">
          {/* Logo and tagline */}
          <div>
            <div className="flex items-center justify-center gap-3 md:justify-start">
              <div className="flex h-8 w-8 items-center justify-center bg-primary text-primary-foreground text-xs font-bold">
                M
              </div>
              <span className="text-base font-semibold text-foreground">
                Mistral Servicios Metalúrgicos
              </span>
            </div>
            <p className="mt-2 text-sm text-muted-foreground">
              Soluciones metalúrgicas para industria y construcción.
            </p>
          </div>

          {/* Links */}
          <nav className="flex flex-wrap justify-center gap-6 md:justify-end">
            <Link
              href="#servicios"
              className="text-sm text-muted-foreground transition-colors hover:text-foreground"
            >
              Servicios
            </Link>
            <Link
              href="#nosotros"
              className="text-sm text-muted-foreground transition-colors hover:text-foreground"
            >
              Nosotros
            </Link>
            <Link
              href="#proyectos"
              className="text-sm text-muted-foreground transition-colors hover:text-foreground"
            >
              Proyectos
            </Link>
            <Link
              href="#contacto"
              className="text-sm text-muted-foreground transition-colors hover:text-foreground"
            >
              Contacto
            </Link>
          </nav>
        </div>

        <div className="mt-8 border-t border-border pt-6 text-center">
          <p className="text-xs text-muted-foreground">
            © {new Date().getFullYear()} Mistral Servicios Metalúrgicos. Todos los derechos reservados.
          </p>
        </div>
      </div>
    </footer>
  )
}
