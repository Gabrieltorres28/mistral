import Link from "next/link"
import { MessageCircle, Phone, Mail, MapPin } from "lucide-react"
import { Button } from "@/components/ui/button"

export function Contact() {
  return (
    <section id="contacto" className="bg-primary py-16 lg:py-24">
      <div className="mx-auto max-w-6xl px-4 lg:px-6">
        <div className="grid items-center gap-12 lg:grid-cols-2 lg:gap-16">
          {/* CTA */}
          <div>
            <h2 className="text-2xl font-bold tracking-tight text-primary-foreground sm:text-3xl">
              Hablemos de su proyecto
            </h2>
            <p className="mt-4 max-w-md text-pretty text-primary-foreground/80">
              Contáctenos para solicitar un presupuesto o consultar sobre nuestros servicios. 
              Respondemos en el día.
            </p>
            <div className="mt-8">
              <Button
                asChild
                size="lg"
                variant="secondary"
                className="gap-2 font-medium"
              >
                <Link
                  href="https://wa.me/5491100000000"
                  target="_blank"
                  rel="noopener noreferrer"
                >
                  <MessageCircle className="h-5 w-5" />
                  Escribir por WhatsApp
                </Link>
              </Button>
            </div>
          </div>

          {/* Contact info */}
          <div className="space-y-6">
            <div className="flex items-start gap-4">
              <div className="flex h-10 w-10 shrink-0 items-center justify-center bg-primary-foreground/10">
                <Phone className="h-5 w-5 text-primary-foreground" />
              </div>
              <div>
                <p className="text-sm font-medium text-primary-foreground">Teléfono</p>
                <p className="mt-1 text-primary-foreground/80">+54 11 0000-0000</p>
              </div>
            </div>

            <div className="flex items-start gap-4">
              <div className="flex h-10 w-10 shrink-0 items-center justify-center bg-primary-foreground/10">
                <Mail className="h-5 w-5 text-primary-foreground" />
              </div>
              <div>
                <p className="text-sm font-medium text-primary-foreground">Email</p>
                <p className="mt-1 text-primary-foreground/80">contacto@mistral.com</p>
              </div>
            </div>

            <div className="flex items-start gap-4">
              <div className="flex h-10 w-10 shrink-0 items-center justify-center bg-primary-foreground/10">
                <MapPin className="h-5 w-5 text-primary-foreground" />
              </div>
              <div>
                <p className="text-sm font-medium text-primary-foreground">Ubicación</p>
                <p className="mt-1 text-primary-foreground/80">Buenos Aires, Argentina</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}
