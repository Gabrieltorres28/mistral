const projects = [
  {
    title: "Estructura para galpón industrial",
    category: "Estructuras metálicas",
    placeholder: "Imagen del proyecto",
  },
  {
    title: "Mantenimiento de línea de producción",
    category: "Mantenimiento industrial",
    placeholder: "Imagen del proyecto",
  },
  {
    title: "Fabricación de piezas especiales",
    category: "Trabajos a medida",
    placeholder: "Imagen del proyecto",
  },
]

export function Projects() {
  return (
    <section id="proyectos" className="bg-background py-16 lg:py-24">
      <div className="mx-auto max-w-6xl px-4 lg:px-6">
        <div className="mb-12 text-center lg:mb-16">
          <h2 className="text-2xl font-bold tracking-tight text-foreground sm:text-3xl">
            Trabajos realizados
          </h2>
          <p className="mx-auto mt-4 max-w-2xl text-pretty text-muted-foreground">
            Algunos ejemplos de proyectos que hemos desarrollado para nuestros clientes.
          </p>
        </div>

        <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
          {projects.map((project, index) => (
            <div key={index} className="group overflow-hidden border border-border bg-card">
              {/* Image placeholder */}
              <div className="aspect-[4/3] bg-muted">
                <div className="flex h-full w-full items-center justify-center">
                  <div className="text-center">
                    <div className="text-4xl font-bold text-muted-foreground/30">
                      {index + 1}
                    </div>
                    <p className="mt-2 text-xs text-muted-foreground/50">
                      {project.placeholder}
                    </p>
                  </div>
                </div>
              </div>
              {/* Content */}
              <div className="p-4">
                <p className="text-xs font-medium uppercase tracking-wider text-muted-foreground">
                  {project.category}
                </p>
                <h3 className="mt-1 font-semibold text-card-foreground">
                  {project.title}
                </h3>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}
