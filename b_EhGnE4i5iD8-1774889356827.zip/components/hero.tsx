import Link from "next/link"
import { ArrowRight, MessageCircle } from "lucide-react"
import { Button } from "@/components/ui/button"

export function Hero() {
  return (
    <section className="relative overflow-hidden bg-primary">
      <div className="absolute inset-0 bg-[url('/hero-pattern.svg')] opacity-5" />
      <div className="relative mx-auto max-w-6xl px-4 py-20 lg:px-6 lg:py-32">
        <div className="grid items-center gap-12 lg:grid-cols-2 lg:gap-16">
          {/* Content */}
          <div className="flex flex-col gap-6">
            <h1 className="text-balance text-3xl font-bold tracking-tight text-primary-foreground sm:text-4xl lg:text-5xl">
              Soluciones metalúrgicas para industria, obras y mantenimiento
            </h1>
            <p className="max-w-xl text-pretty text-base text-primary-foreground/80 lg:text-lg">
              Fabricación, soldaduras, estructuras y servicios técnicos con respuesta eficiente y calidad comprobada.
            </p>
            <div className="flex flex-col gap-3 pt-2 sm:flex-row sm:gap-4">
              <Button
                asChild
                size="lg"
                variant="secondary"
                className="gap-2 font-medium"
              >
                <Link
                  href="https://wa.me/5491100000000"
                  target="_blank"
                  rel="noopener noreferrer"
                >
                  <MessageCircle className="h-5 w-5" />
                  Contactar por WhatsApp
                </Link>
              </Button>
              <Button
                asChild
                size="lg"
                variant="outline"
                className="gap-2 border-primary-foreground/30 bg-transparent font-medium text-primary-foreground hover:bg-primary-foreground/10 hover:text-primary-foreground"
              >
                <Link href="#servicios">
                  Ver servicios
                  <ArrowRight className="h-4 w-4" />
                </Link>
              </Button>
            </div>
          </div>

          {/* Visual placeholder */}
          <div className="relative hidden lg:block">
            <div className="aspect-[4/3] overflow-hidden bg-muted/10">
              <div className="flex h-full w-full items-center justify-center border border-primary-foreground/20 bg-primary-foreground/5">
                <div className="text-center">
                  <div className="text-6xl font-bold text-primary-foreground/20">M</div>
                  <p className="mt-2 text-sm text-primary-foreground/40">
                    Imagen de taller o equipo
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}
