import { Wrench, Layers, Settings, Building2, Ruler, Cog } from "lucide-react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"

const services = [
  {
    icon: Wrench,
    title: "Fabricación metálica",
    description: "Piezas, estructuras y componentes fabricados según planos o especificaciones del cliente.",
  },
  {
    icon: Layers,
    title: "Soldaduras y montajes",
    description: "Soldadura MIG, TIG y electrodo. Montaje en planta o en obra con personal calificado.",
  },
  {
    icon: Settings,
    title: "Mantenimiento industrial",
    description: "Reparación de equipos, maquinaria y estructuras. Servicio preventivo y correctivo.",
  },
  {
    icon: Building2,
    title: "Estructuras metálicas",
    description: "Diseño y construcción de estructuras para galpones, entrepisos, escaleras y más.",
  },
  {
    icon: Ruler,
    title: "Trabajos a medida",
    description: "Proyectos especiales adaptados a las necesidades específicas de cada cliente.",
  },
  {
    icon: Cog,
    title: "Reformas y soluciones técnicas",
    description: "Modificaciones, ampliaciones y mejoras en instalaciones existentes.",
  },
]

export function Services() {
  return (
    <section id="servicios" className="bg-background py-16 lg:py-24">
      <div className="mx-auto max-w-6xl px-4 lg:px-6">
        <div className="mb-12 text-center lg:mb-16">
          <h2 className="text-2xl font-bold tracking-tight text-foreground sm:text-3xl">
            Nuestros servicios
          </h2>
          <p className="mx-auto mt-4 max-w-2xl text-pretty text-muted-foreground">
            Brindamos soluciones integrales en metalurgia para industrias, constructoras y empresas de mantenimiento.
          </p>
        </div>

        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3 lg:gap-6">
          {services.map((service) => (
            <Card key={service.title} className="border-border bg-card transition-colors hover:border-muted-foreground/30">
              <CardHeader className="pb-3">
                <div className="mb-2 flex h-10 w-10 items-center justify-center bg-secondary">
                  <service.icon className="h-5 w-5 text-accent" />
                </div>
                <CardTitle className="text-lg font-semibold text-card-foreground">
                  {service.title}
                </CardTitle>
              </CardHeader>
              <CardContent>
                <CardDescription className="text-sm leading-relaxed text-muted-foreground">
                  {service.description}
                </CardDescription>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </section>
  )
}
